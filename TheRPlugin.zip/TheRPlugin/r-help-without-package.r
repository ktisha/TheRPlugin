args <- commandArgs(TRUE)
help(args[1])